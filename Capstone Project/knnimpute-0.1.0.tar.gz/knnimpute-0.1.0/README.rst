|Build Status| |Coverage Status|

knnimpute
=========

Multiple implementations of kNN imputation in pure Python + NumPy

.. |Build Status| image:: https://travis-ci.org/hammerlab/knnimpute.svg?branch=master
   :target: https://travis-ci.org/hammerlab/knnimpute
.. |Coverage Status| image:: https://coveralls.io/repos/github/hammerlab/knnimpute/badge.svg?branch=master
   :target: https://coveralls.io/github/hammerlab/knnimpute?branch=master
